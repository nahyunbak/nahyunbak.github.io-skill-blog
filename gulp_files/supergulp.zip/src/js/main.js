import { random } from "./util";

const rOne = random(10);
const rTwo = random(20);

console.log(`${rOne} $r{Two}`);